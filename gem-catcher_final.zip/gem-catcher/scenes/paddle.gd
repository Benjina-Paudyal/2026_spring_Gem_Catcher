extends Area2D

@export var speed : float = 200.0

func _process(delta: float) -> void:
	# MOVE PADDLE USING INPUT MAP (8)
	if Input.is_action_pressed("left"):
		position.x -= speed * delta
	if Input.is_action_pressed("right"):
		position.x += speed * delta
