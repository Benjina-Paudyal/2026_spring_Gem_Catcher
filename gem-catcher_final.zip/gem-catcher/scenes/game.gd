extends Node2D

const EXPLODE = preload("res://assets/explode.wav")

@export var gem_scene : PackedScene

@onready var score_label: Label = $Label
@onready var timer: Timer = $Timer
@onready var audio_stream_player_2d: AudioStreamPlayer2D = $AudioStreamPlayer2D

var _score : int = 0

func spawn_gem() -> void:
	# INSTANTIATE GEM
	var new_gem: Gem = gem_scene.instantiate()
	var xpos: float = randf_range(70.0, 1050.0)
	new_gem.position = Vector2(xpos, -50)
	add_child(new_gem)
	
	# CONNECT GEM SIGNAL TO GAME OVER
	new_gem.gem_off_screen.connect(game_over)

func stop_all() -> void:
	timer.stop()
	for c in get_children():
		c.set_process(false)

func play_explosion() -> void:
	audio_stream_player_2d.stop()
	audio_stream_player_2d.stream = EXPLODE
	audio_stream_player_2d.play()

func game_over() -> void:
	stop_all()
	play_explosion()

func _on_timer_timeout() -> void:
	spawn_gem()

func _on_paddle_area_entered(area: Area2D) -> void:
	_score += 1
	score_label.text = "%05d" % _score
	audio_stream_player_2d.position = area.position
	audio_stream_player_2d.play()
	area.queue_free()
