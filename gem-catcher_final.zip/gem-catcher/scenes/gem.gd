extends Area2D # INHERITANCE

class_name Gem

signal gem_off_screen

@export var speed : float = 100.0

func _process(delta: float) -> void:
	# FÅ GEM TIL AT FALDE (6)
	position.y += speed * delta
	
	# FJERNE GEM I BUNDEN AF SKÆRMEN (7)
	if position.y > get_viewport_rect().size.y:
		gem_off_screen.emit()
		set_process(false)
		queue_free()
